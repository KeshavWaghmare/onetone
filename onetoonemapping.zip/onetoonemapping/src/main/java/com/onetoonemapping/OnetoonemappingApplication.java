package com.onetoonemapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnetoonemappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnetoonemappingApplication.class, args);
	}

}
