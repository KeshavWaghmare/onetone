package com.onetoonemapping.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onetoonemapping.model.DemandFulfillment;
import com.onetoonemapping.repository.DemandCreationRepository;
import com.onetoonemapping.repository.DemandFulFillmentRepository;
import com.onetoonemapping.service.DemandFulfillmentService;
import com.onetoonemapping.service.InstructorDetailsService;
@Service
public class DemandFulfillmentServiceImpl implements DemandFulfillmentService {

	@Autowired
	private DemandFulFillmentRepository demandFulfillmentRepository;
	
	@Override
	public DemandFulfillment postDemandFulfillment(DemandFulfillment demandFulfillment) {
		// TODO Auto-generated method stub
		return this.demandFulfillmentRepository.save(demandFulfillment);
	}

	@Override
	public Optional<DemandFulfillment> getDemandFulfillment(Long id) {
		// TODO Auto-generated method stub
		return this.demandFulfillmentRepository.findById(id);
	}

	@Override
	public DemandFulfillment updateDemandFulfillment(DemandFulfillment demandFulfillment) {
		// TODO Auto-generated method stub
		return this.demandFulfillmentRepository.save(demandFulfillment);
	}

}
