package com.onetoonemapping.service;

import java.util.Optional;

import com.onetoonemapping.model.DemandFulfillment;
import com.onetoonemapping.model.InstructorDetail;

public interface DemandFulfillmentService {

public DemandFulfillment postDemandFulfillment(DemandFulfillment demandFulfillment);
	
	public Optional<DemandFulfillment> getDemandFulfillment(Long id);
	
	public DemandFulfillment updateDemandFulfillment(DemandFulfillment demandFulfillment);
	
	
}
