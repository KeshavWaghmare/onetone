package com.onetoonemapping.service;

import java.util.List;

import com.onetoonemapping.model.Instructor;
import com.onetoonemapping.model.InstructorDetail;

public interface InstructionService {
	
	public List<Instructor> listInstructor();
	
	public Instructor postInstructor(Instructor instructor);
	
	
}
