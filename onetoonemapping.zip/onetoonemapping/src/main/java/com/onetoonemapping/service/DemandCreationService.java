package com.onetoonemapping.service;

import java.util.List;

import com.onetoonemapping.exception.ResourceNotFoundException;
import com.onetoonemapping.model.DemandCreation;


public interface DemandCreationService {

public List<DemandCreation> listDemandCreation();
	
	public DemandCreation postDemandCreation(DemandCreation demandCreation);
	
	public DemandCreation getOneDemandCreation(Long id) throws ResourceNotFoundException;
	
//	public DemandCreation updateDemandCreation(DemandCreation demandCreation,Long id) throws ResourceNotFoundException;

	public DemandCreation updateDemandCreation(DemandCreation demandCreation);
}
