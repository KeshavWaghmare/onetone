package com.onetoonemapping.service;

import java.util.Optional;

import com.onetoonemapping.model.InstructorDetail;

public interface InstructorDetailsService {

	public InstructorDetail postInstructorDetails(InstructorDetail instructorDetails);
	
	public Optional<InstructorDetail> getInstructorDetails(Long id);
	
	public InstructorDetail updateInstructorDetails(InstructorDetail instructorDetails);


}
