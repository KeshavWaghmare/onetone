package com.onetoonemapping.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onetoonemapping.exception.ResourceNotFoundException;
import com.onetoonemapping.model.DemandCreation;
import com.onetoonemapping.repository.DemandCreationRepository;
import com.onetoonemapping.repository.InstructorRepository;
import com.onetoonemapping.service.DemandCreationService;
import com.onetoonemapping.service.InstructionService;
@Service
public class DemandCreationServiceImpl implements DemandCreationService{

	@Autowired
	private DemandCreationRepository demandCreationRepository;
	
	@Override
	public List<DemandCreation> listDemandCreation() {
		// TODO Auto-generated method stub
		return this.demandCreationRepository.findAll();
	}

	@Override
	public DemandCreation postDemandCreation(DemandCreation demandCreation) {
		// TODO Auto-generated method stub
		return this.demandCreationRepository.save(demandCreation);
	}

	@Override
	public DemandCreation getOneDemandCreation(Long id) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		return this.demandCreationRepository.findById(id)
				.orElseThrow(()->new ResourceNotFoundException("Demand not found :: " + id));
	}

	@Override
	public DemandCreation updateDemandCreation(DemandCreation demandCreation) {
		// TODO Auto-generated method stub
		return this.demandCreationRepository.save(demandCreation);
	}

//	@Override
//	public DemandCreation updateDemandCreation(DemandCreation demandCreation, Long id) throws ResourceNotFoundException {
//		// TODO Auto-generated method stub
//		DemandCreation demandCreation1= this.demandCreationRepository.findById(id)
//				.orElseThrow(()->new ResourceNotFoundException("Demand not update found :: " + id));
//		return this.demandCreationRepository.save(demandCreation1);
//	}

}
