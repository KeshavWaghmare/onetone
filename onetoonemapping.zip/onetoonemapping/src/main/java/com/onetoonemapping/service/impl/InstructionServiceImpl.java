package com.onetoonemapping.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onetoonemapping.model.Instructor;
import com.onetoonemapping.repository.InstructorRepository;
import com.onetoonemapping.service.InstructionService;

@Service
public class InstructionServiceImpl implements InstructionService{

	@Autowired
	private InstructorRepository instructorRepository;
	
	@Override
	public List<Instructor> listInstructor() {
		// TODO Auto-generated method stub
		return this.instructorRepository.findAll();
	}

	@Override
	public Instructor postInstructor(Instructor instructor) {
		// TODO Auto-generated method stub
		return this.instructorRepository.save(instructor);
	}

}
