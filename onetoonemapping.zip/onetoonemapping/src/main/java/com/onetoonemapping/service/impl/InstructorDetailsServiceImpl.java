package com.onetoonemapping.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onetoonemapping.model.InstructorDetail;
import com.onetoonemapping.repository.InstructorDtailsRepository;
import com.onetoonemapping.service.InstructorDetailsService;

@Service
public class InstructorDetailsServiceImpl implements InstructorDetailsService{
  
	@Autowired
	private InstructorDtailsRepository instructorDetailsRepository; 
	@Override
	public InstructorDetail postInstructorDetails(InstructorDetail instructorDetails) {
		// TODO Auto-generated method stub
		return this.instructorDetailsRepository.save(instructorDetails);
	}

	@Override
	public Optional<InstructorDetail> getInstructorDetails(Long id) {
		// TODO Auto-generated method stub
		return this.instructorDetailsRepository.findById(id);
	}

	@Override
	public InstructorDetail updateInstructorDetails(InstructorDetail instructorDetails) {
		// TODO Auto-generated method stub
		
		return this.instructorDetailsRepository.save(instructorDetails);
	}

}
