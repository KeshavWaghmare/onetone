package com.onetoonemapping.model;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class DemandCreation {
	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	private Long demandId;
	private String billingRole;
	private int billingRate;
	private String location;
	private String city;
	private String probability;
	private String skillSet;
	private String jobDescription;
	private String priority;
	private String clientInterview;
	private String newOrReplacement;
	private String tower;
	private String programName;
	private String csg;
	private String clientManager;
	private String citizensCio;

	private Date requestRecieved;
	private Date expectedDateOfFulFillment;
	
	   @OneToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "demand_fulfillment_id")
	    private DemandFulfillment demandFulfillment;

	public Long getDemandId() {
		return demandId;
	}

	public void setDemandId(Long demandId) {
		this.demandId = demandId;
	}

	public String getBillingRole() {
		return billingRole;
	}

	public void setBillingRole(String billingRole) {
		this.billingRole = billingRole;
	}

	public int getBillingRate() {
		return billingRate;
	}

	public void setBillingRate(int billingRate) {
		this.billingRate = billingRate;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getProbability() {
		return probability;
	}

	public void setProbability(String probability) {
		this.probability = probability;
	}

	public String getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}

	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getClientInterview() {
		return clientInterview;
	}

	public void setClientInterview(String clientInterview) {
		this.clientInterview = clientInterview;
	}

	public String getNewOrReplacement() {
		return newOrReplacement;
	}

	public void setNewOrReplacement(String newOrReplacement) {
		this.newOrReplacement = newOrReplacement;
	}

	public String getTower() {
		return tower;
	}

	public void setTower(String tower) {
		this.tower = tower;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getCsg() {
		return csg;
	}

	public void setCsg(String csg) {
		this.csg = csg;
	}

	public String getClientManager() {
		return clientManager;
	}

	public void setClientManager(String clientManager) {
		this.clientManager = clientManager;
	}

	public String getCitizensCio() {
		return citizensCio;
	}

	public void setCitizensCio(String citizensCio) {
		this.citizensCio = citizensCio;
	}

	public Date getRequestRecieved() {
		return requestRecieved;
	}

	public void setRequestRecieved(Date requestRecieved) {
		this.requestRecieved = requestRecieved;
	}

	public Date getExpectedDateOfFulFillment() {
		return expectedDateOfFulFillment;
	}

	public void setExpectedDateOfFulFillment(Date expectedDateOfFulFillment) {
		this.expectedDateOfFulFillment = expectedDateOfFulFillment;
	}

	public DemandFulfillment getDemandFulfillment() {
		return demandFulfillment;
	}

	public void setDemandFulfillment(DemandFulfillment demandFulfillment) {
		this.demandFulfillment = demandFulfillment;
	}

	public DemandCreation(Long demandId, String billingRole, int billingRate, String location, String city,
			String probability, String skillSet, String jobDescription, String priority, String clientInterview,
			String newOrReplacement, String tower, String programName, String csg, String clientManager,
			String citizensCio, Date requestRecieved, Date expectedDateOfFulFillment,
			DemandFulfillment demandFulfillment) {
		super();
		this.demandId = demandId;
		this.billingRole = billingRole;
		this.billingRate = billingRate;
		this.location = location;
		this.city = city;
		this.probability = probability;
		this.skillSet = skillSet;
		this.jobDescription = jobDescription;
		this.priority = priority;
		this.clientInterview = clientInterview;
		this.newOrReplacement = newOrReplacement;
		this.tower = tower;
		this.programName = programName;
		this.csg = csg;
		this.clientManager = clientManager;
		this.citizensCio = citizensCio;
		this.requestRecieved = requestRecieved;
		this.expectedDateOfFulFillment = expectedDateOfFulFillment;
		this.demandFulfillment = demandFulfillment;
	}

	public DemandCreation() {
		super();
		// TODO Auto-generated constructor stub
	}
	 
	 
	




}
