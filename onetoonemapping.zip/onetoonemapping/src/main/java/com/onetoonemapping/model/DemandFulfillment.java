package com.onetoonemapping.model;


import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class DemandFulfillment {
	 @Id
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Long demandFullId;
	 
	 
	private String status;
	private String infosysPU;
	private String profileSourcingPlan;
	private String profileShare;
	private Date profileSharedDate;
	private Date profileConfirmedDate;
	private Date plannedOnboardingDate;
	private Date actualOnboardingDate;
	private String deliveryAnchor;
	private Long tmsId;
	private String cancelledReason;
	private String fullfillmentRemark;
	private Date plannedDateOfFullfillment;
	private String jl;
	private String resourceName;
	private Long employeeId;
	private Date demandConfirmedDate;
	public Long getDemandFullId() {
		return demandFullId;
	}
	public void setDemandFullId(Long demandFullId) {
		this.demandFullId = demandFullId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getInfosysPU() {
		return infosysPU;
	}
	public void setInfosysPU(String infosysPU) {
		this.infosysPU = infosysPU;
	}
	public String getProfileSourcingPlan() {
		return profileSourcingPlan;
	}
	public void setProfileSourcingPlan(String profileSourcingPlan) {
		this.profileSourcingPlan = profileSourcingPlan;
	}
	public String getProfileShare() {
		return profileShare;
	}
	public void setProfileShare(String profileShare) {
		this.profileShare = profileShare;
	}
	public Date getProfileSharedDate() {
		return profileSharedDate;
	}
	public void setProfileSharedDate(Date profileSharedDate) {
		this.profileSharedDate = profileSharedDate;
	}
	public Date getProfileConfirmedDate() {
		return profileConfirmedDate;
	}
	public void setProfileConfirmedDate(Date profileConfirmedDate) {
		this.profileConfirmedDate = profileConfirmedDate;
	}
	public Date getPlannedOnboardingDate() {
		return plannedOnboardingDate;
	}
	public void setPlannedOnboardingDate(Date plannedOnboardingDate) {
		this.plannedOnboardingDate = plannedOnboardingDate;
	}
	public Date getActualOnboardingDate() {
		return actualOnboardingDate;
	}
	public void setActualOnboardingDate(Date actualOnboardingDate) {
		this.actualOnboardingDate = actualOnboardingDate;
	}
	public String getDeliveryAnchor() {
		return deliveryAnchor;
	}
	public void setDeliveryAnchor(String deliveryAnchor) {
		this.deliveryAnchor = deliveryAnchor;
	}
	public Long getTmsId() {
		return tmsId;
	}
	public void setTmsId(Long tmsId) {
		this.tmsId = tmsId;
	}
	public String getCancelledReason() {
		return cancelledReason;
	}
	public void setCancelledReason(String cancelledReason) {
		this.cancelledReason = cancelledReason;
	}
	public String getFullfillmentRemark() {
		return fullfillmentRemark;
	}
	public void setFullfillmentRemark(String fullfillmentRemark) {
		this.fullfillmentRemark = fullfillmentRemark;
	}
	public Date getPlannedDateOfFullfillment() {
		return plannedDateOfFullfillment;
	}
	public void setPlannedDateOfFullfillment(Date plannedDateOfFullfillment) {
		this.plannedDateOfFullfillment = plannedDateOfFullfillment;
	}
	public String getJl() {
		return jl;
	}
	public void setJl(String jl) {
		this.jl = jl;
	}
	public String getResourceName() {
		return resourceName;
	}
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}
	public Long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}
	public Date getDemandConfirmedDate() {
		return demandConfirmedDate;
	}
	public void setDemandConfirmedDate(Date demandConfirmedDate) {
		this.demandConfirmedDate = demandConfirmedDate;
	}
	public DemandFulfillment(Long demandFullId, String status, String infosysPU, String profileSourcingPlan,
			String profileShare, Date profileSharedDate, Date profileConfirmedDate, Date plannedOnboardingDate,
			Date actualOnboardingDate, String deliveryAnchor, Long tmsId, String cancelledReason,
			String fullfillmentRemark, Date plannedDateOfFullfillment, String jl, String resourceName, Long employeeId,
			Date demandConfirmedDate) {
		super();
		this.demandFullId = demandFullId;
		this.status = status;
		this.infosysPU = infosysPU;
		this.profileSourcingPlan = profileSourcingPlan;
		this.profileShare = profileShare;
		this.profileSharedDate = profileSharedDate;
		this.profileConfirmedDate = profileConfirmedDate;
		this.plannedOnboardingDate = plannedOnboardingDate;
		this.actualOnboardingDate = actualOnboardingDate;
		this.deliveryAnchor = deliveryAnchor;
		this.tmsId = tmsId;
		this.cancelledReason = cancelledReason;
		this.fullfillmentRemark = fullfillmentRemark;
		this.plannedDateOfFullfillment = plannedDateOfFullfillment;
		this.jl = jl;
		this.resourceName = resourceName;
		this.employeeId = employeeId;
		this.demandConfirmedDate = demandConfirmedDate;
	}
	public DemandFulfillment() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
