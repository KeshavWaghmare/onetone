package com.onetoonemapping.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onetoonemapping.model.Instructor;
import com.onetoonemapping.service.InstructionService;

@RestController
@RequestMapping("/api/v1")
public class controller {
	
	@Autowired
	private InstructionService instructorService;
	
	  @GetMapping("/instructors")
	    public List < Instructor > getInstructors() {
	        return instructorService.listInstructor();
	    }
	  
	  @PostMapping("/instructors")
	    public Instructor createUser( @RequestBody Instructor instructor) {
	        return instructorService.postInstructor(instructor);
	    }


}
