package com.onetoonemapping.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onetoonemapping.model.DemandFulfillment;
import com.onetoonemapping.model.InstructorDetail;
import com.onetoonemapping.service.DemandFulfillmentService;
import com.onetoonemapping.service.InstructorDetailsService;

@RestController
@RequestMapping("/api/v1")
public class DemandFulfillmentController {
	
	@Autowired
	private DemandFulfillmentService instructorDetailsService;
	
	  @GetMapping("/fulfillment/{id}")
	    public Optional<DemandFulfillment> getDemandFulfillment(@PathVariable("id") Long id) {
	        return instructorDetailsService.getDemandFulfillment(id);
	    }
	  
	  @PostMapping("/fulfillment")
	    public DemandFulfillment createDemandFulfillment( @RequestBody DemandFulfillment demandFulfillment) {
	        return instructorDetailsService.postDemandFulfillment(demandFulfillment);
	    }

     @PutMapping("/fulfillment")
     public DemandFulfillment updateDemandFulfillment(@RequestBody DemandFulfillment demandFulfillment)
     {
    	 return this.instructorDetailsService.updateDemandFulfillment(demandFulfillment);
     }


}
