package com.onetoonemapping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onetoonemapping.exception.ResourceNotFoundException;
import com.onetoonemapping.model.DemandCreation;
import com.onetoonemapping.model.Instructor;
import com.onetoonemapping.service.DemandCreationService;
import com.onetoonemapping.service.InstructionService;

@RestController
@RequestMapping("/api/v1")
public class DemandCreationController {

	
	@Autowired
	private DemandCreationService demandCreationService;
	
	  @GetMapping("/creation")
	    public List < DemandCreation > getDemandCreation() {
	        return demandCreationService.listDemandCreation();
	    }
	  
	  @GetMapping("/creation/{id}")
	    public  DemandCreation  getOneDemandCreation(@PathVariable("id") Long id) throws ResourceNotFoundException {
	        return demandCreationService.getOneDemandCreation(id);
	    }
	  
	  @PostMapping("/creation")
	    public DemandCreation createDemandCreation( @RequestBody DemandCreation demandCreation) {
	        return demandCreationService.postDemandCreation(demandCreation);
	    }
	  
//	  @PutMapping("/creation/{id}")
//	    public DemandCreation updateDemandCreation( @RequestBody DemandCreation demandCreation,@PathVariable("id") Long id) throws ResourceNotFoundException {
//	        return demandCreationService.updateDemandCreation(demandCreation, id);
//	    }

	  @PutMapping("/creation")
	    public DemandCreation updateDemandCreation( @RequestBody DemandCreation demandCreation) throws ResourceNotFoundException {
	        return demandCreationService.updateDemandCreation(demandCreation);
	    }
}
