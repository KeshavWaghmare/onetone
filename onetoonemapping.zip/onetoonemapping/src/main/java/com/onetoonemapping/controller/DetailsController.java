package com.onetoonemapping.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.onetoonemapping.model.Instructor;
import com.onetoonemapping.model.InstructorDetail;
import com.onetoonemapping.service.InstructionService;
import com.onetoonemapping.service.InstructorDetailsService;

@RestController
@RequestMapping("/api/v1")
public class DetailsController {
	@Autowired
	private InstructorDetailsService instructorDetailsService;
	
	  @GetMapping("/details/{id}")
	    public Optional<InstructorDetail> getInstructors(@PathVariable("id") Long id) {
	        return instructorDetailsService.getInstructorDetails(id);
	    }
	  
	  @PostMapping("/details")
	    public InstructorDetail createUser( @RequestBody InstructorDetail instructorDetail) {
	        return instructorDetailsService.postInstructorDetails(instructorDetail);
	    }

     @PutMapping("/details")
     public InstructorDetail updateInstructorDetail(@RequestBody InstructorDetail instructorDetail)
     {
    	 return this.instructorDetailsService.updateInstructorDetails(instructorDetail);
     }
}
