package com.onetoonemapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnetoonemappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
